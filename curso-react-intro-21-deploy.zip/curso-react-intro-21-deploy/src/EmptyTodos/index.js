import React from 'react';

function EmptyTodos() {
  return (
    <p>¡Crea tu primer TODO!</p>
  );
}

export { EmptyTodos };
