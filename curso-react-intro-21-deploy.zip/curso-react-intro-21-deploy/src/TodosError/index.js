import React from 'react';

function TodosError() {
  return (
    <p>Error...</p>
  );
}

export { TodosError };
